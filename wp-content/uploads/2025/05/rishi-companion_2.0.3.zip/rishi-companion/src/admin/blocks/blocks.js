/**
 * Include all blocks
 */
import "./recent-posts";

/**
 * Include Popular Posts blocks
 */
import "./popular-posts";

/**
 * Include Categories blocks
 */
import "./categories";

/**
* Include Advertisements blocks
*/
import "./advertisement"; 

/**
 * Include Author Bio blocks
 */
import "./author-bio";

/**
 * Include Posts Tab blocks
 */
import "./posts-tab";
/**
 * Include Pinterest blocks
 */
import "./pinterest";

/**
  * Include Facebook blocks
*/
import "./facebook";
