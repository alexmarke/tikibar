jQuery(document).ready(function($){
    //Sortable for Team social links
    $('.user-social-sortable-icons').sortable({
        cursor: "move"
    });   
});